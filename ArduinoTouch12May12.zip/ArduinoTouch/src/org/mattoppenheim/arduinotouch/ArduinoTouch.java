/**
 * Based on code from the book Arduino + Android Projects for the Evil Genius
 * <br>Copyright 2011 Simon Monk
 *
 
 */

package org.mattoppenheim.arduinotouch;

import java.io.File;
import java.io.IOException;

import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class ArduinoTouch extends BaseActivity implements OnClickListener {
	static final String TAG = "DemoKitPhone";
	/** Called when the activity is first created. */
	TextView mInputLabel;
	LinearLayout mInputContainer;
	Drawable mFocusedTabImage;
	Drawable mNormalTabImage;
	static Button[] buttons; // for the mTouch buttons

	@Override
	protected void hideControls() {
		super.hideControls();
	}

	public void onCreate(Bundle savedInstanceState) {
		mFocusedTabImage = getResources().getDrawable(
				R.drawable.tab_focused_holo_dark);
		mNormalTabImage = getResources().getDrawable(
				R.drawable.tab_normal_holo_dark);
		super.onCreate(savedInstanceState);

		// Create buttons and listeners

		buttons = new Button[16]; // create an array of 16 buttons

		for (int i=0; i<buttons.length; i++){
			{
				String buttonID = "mButton" + i; // create mButton0 to mButton15
				int resID = getResources().getIdentifier(buttonID, "id", getPackageName());// find the identifier for the Button
				buttons[i] = ((Button) findViewById(resID));
				buttons[i].setOnClickListener(this); 
				Debug.out("made button " + buttonID ); // debugging info
			}
		}//~ for
	}
	
// accessor method to access buttons
	public static void serviceButton(int ident){
		buttons[ident].performClick();
	}
	
	protected void showControls() {
		super.showControls();
		mInputLabel = (TextView) findViewById(R.id.inputLabel);
		mInputContainer = (LinearLayout) findViewById(R.id.inputContainer);
		showTabContents(true);
	}

	void showTabContents(Boolean showInput) {
		if (showInput) {
			mInputContainer.setVisibility(View.VISIBLE);
			mInputLabel.setBackgroundDrawable(mFocusedTabImage);
		} else {
			mInputContainer.setVisibility(View.GONE);
			mInputLabel.setBackgroundDrawable(mNormalTabImage);
		}
	}
	
	// Handles the onClick event for the mButtons
	@Override
	public void onClick(View v){
		Debug.out("onClick started "); // debugging info
		int index = 0;	
		for(int i=0; i<buttons.length; i++)
		{
			if (buttons[i].getId() == v.getId())
			{
				index = i; // this is the channel
				break;
			}//if

		}//~for
		clickButton(buttons[index]); // click the soft button
		playAudio("channel_"+index); // play the audio tag	
		Debug.out("onClick called for channel "+index); // debugging info sent to LogCat tab in Eclipse
	}//~onClick

/*	Does performClick with a visual change of the button
Uses a Handler to instigate the colour change after a set time*/
public static void clickButton (final Button passedButton)
{
	passedButton.setBackgroundColor(Color.GREEN); // change activated button colour
	Handler handler = new Handler();
	Runnable r = new Runnable() {
		@Override
		public void run() {
	    	passedButton.setBackgroundColor(Color.YELLOW);
		}
	};
// 150ms delay before returning the button colour to the original
	handler.postDelayed(r, 150);
	} // end clickButton

public static void playAudio (String channel)
{

	//	EditText editText = (EditText)findViewById(R.id.title); // crashes program
	/*	    	if (player != null) {
		player.stop(); // stop the last player
	}*/
	String FILE_LOCATION = "sdcard/TouchButtons/" + channel + ".3gp";
	File file = new File(FILE_LOCATION);
	if(!file.exists()) { // Check that the file exists
		//    		editText.setText("Sound file not found"); // crashes program
	}
	final MediaPlayer player = new MediaPlayer();
	try {
		player.setDataSource(FILE_LOCATION);
		player.prepare();
	} catch (IllegalStateException e) {
		e.printStackTrace();
//		Toast.makeText(this,e.toString(),Toast.LENGTH_LONG).show();			
	} catch (IOException e) {
		e.printStackTrace();
//		Toast.makeText(this,e.toString(),Toast.LENGTH_LONG).show();			
		e.printStackTrace();
	}
	player.start();
	//Toast.makeText(this,"audio started",Toast.LENGTH_SHORT).show(); // debugging
	// set a Listener for when the audio clip stops, then release the MediaPlayer resources
	player.setOnCompletionListener(new OnCompletionListener() {	
		// release MediaPlayer resources on completion of play back
		public void onCompletion(MediaPlayer arg0) {
			player.stop(); // ? superfluous
			player.release();	// release system resources	
		}
	});
	
} // end playAudio	    
}// ~ ArduinoTouch