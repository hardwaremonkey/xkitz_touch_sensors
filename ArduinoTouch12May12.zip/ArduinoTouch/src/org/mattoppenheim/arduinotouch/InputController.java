/**
 * code from the book Arduino + Android Projects for the Evil Genius
 * <br>Copyright 2011 Simon Monk
 *
 * <p>This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2
 * as published by the Free Software Foundation (see COPYING).
 * 
 * <p>This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

package org.mattoppenheim.arduinotouch;

import android.media.MediaPlayer;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

public class InputController extends AccessoryController {
	private TextView mTemperature;
	private ImageView mRadiationImage;
	private TextView mLogView;
	
	private ArduinoTouchActivity mHostActivity;
	private MediaPlayer mp;
	

	InputController(ArduinoTouchActivity hostActivity) {
		super(hostActivity);
		mHostActivity = hostActivity;
		mTemperature = (TextView) findViewById(R.id.tempValue);
		mRadiationImage = (ImageView) findViewById(R.id.radImage);
		mLogView = (TextView) findViewById(R.id.logField);
		mp = MediaPlayer.create(mHostActivity, R.raw.click);

		mRadiationImage.setVisibility(ImageView.INVISIBLE);

	}

	
	protected void onAccesssoryAttached() {
	}
	
	public void clearLog()
	{
		mLogView.setText("Messages");
	}

	public void handleGeigerMessage(char flag, int reading) {
		Log.d("SRM", "setTemp " + reading);
		if (flag == 'E') // Event - makes classic click sound
		{
			mRadiationImage.setVisibility(ImageView.VISIBLE);
			mp.start();
		}
		else if (flag == 'R') // Channel on
		{
			mRadiationImage.setVisibility(ImageView.VISIBLE);
			mTemperature.setText("Channel " + reading + " on");
			mLogView.setText("Channel " + reading + " On" + "\n");
			mp.start(); // make clicking sound
			mHostActivity.activateButton(reading);
			
		}
		else if (flag == 'L') // Channel off
		{
			//String logText = mLogView.getText().toString();
			//String timeFormatted = (String) DateFormat.format("hh:mm", new Date());
			//mLogView.setText(logText + "\n" + timeFormatted + "\t\t\t" + reading);
			mLogView.setText("Channel " + reading + " Off" + "\n");
		}
	}



}
