/*For sending debug messages to LogCat
write Debug.out("something") to use
from http://stackoverflow.com/questions/2752472/android-how-can-i-print-a-variable-on-eclipse-console
	Window->Show View->Other…->Android->LogCat*/

package org.mattoppenheim.arduinotouch;

import android.util.Log;

public final class Debug{
    private Debug (){}

    public static void out (Object msg){
        Log.i ("info", msg.toString ());
    }
}
