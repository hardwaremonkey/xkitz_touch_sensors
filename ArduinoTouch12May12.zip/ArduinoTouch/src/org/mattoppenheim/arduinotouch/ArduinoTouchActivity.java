/**
 * Based on code from the book Arduino + Android Projects for the Evil Genius
 * <br>Copyright 2011 Simon Monk
 * Zipped version 18Mar12 works
 * Rejigging to tidy up code - remove lists of 16 'if' statements
 *
 
 */

package org.mattoppenheim.arduinotouch;

import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

import com.android.future.usb.UsbAccessory;
import com.android.future.usb.UsbManager;

public class ArduinoTouchActivity extends Activity implements Runnable {
	private static final String TAG = "DemoKit";

	private static final String ACTION_USB_PERMISSION = "com.google.android.DemoKit.action.USB_PERMISSION";

	private UsbManager mUsbManager;
	private PendingIntent mPermissionIntent;
	private boolean mPermissionRequestPending;

	UsbAccessory mAccessory;
	ParcelFileDescriptor mFileDescriptor;
	FileInputStream mInputStream;
	FileOutputStream mOutputStream;
	
	int count = 0;

	private static final int MESSAGE_TEMPERATURE = 2;
	
	protected class GeigerMsg {
		private char flag;
		private int reading;

		public GeigerMsg(char flag, int reading) {
			this.flag = flag;
			this.reading = reading;
		}

		public int getReading() {
			return reading;
		}
		
		public char getFlag() {
			return flag;
		}
	}
	

	private final BroadcastReceiver mUsbReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {
			String action = intent.getAction();
			if (ACTION_USB_PERMISSION.equals(action)) {
				synchronized (this) {
					UsbAccessory accessory = UsbManager.getAccessory(intent);
					if (intent.getBooleanExtra(
							UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
						openAccessory(accessory);
					} else {
						Log.d(TAG, "permission denied for accessory "
								+ accessory);
					}
					mPermissionRequestPending = false;
				}
			} else if (UsbManager.ACTION_USB_ACCESSORY_DETACHED.equals(action)) {
				UsbAccessory accessory = UsbManager.getAccessory(intent);
				if (accessory != null && accessory.equals(mAccessory)) {
					closeAccessory();
				}
			}
		}
	};

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		mUsbManager = UsbManager.getInstance(this);
		mPermissionIntent = PendingIntent.getBroadcast(this, 0, new Intent(
				ACTION_USB_PERMISSION), 0);
		IntentFilter filter = new IntentFilter(ACTION_USB_PERMISSION);
		filter.addAction(UsbManager.ACTION_USB_ACCESSORY_DETACHED);
		registerReceiver(mUsbReceiver, filter);

		if (getLastNonConfigurationInstance() != null) {
			mAccessory = (UsbAccessory) getLastNonConfigurationInstance();
			openAccessory(mAccessory);
		}

		enableControls(false);
		
	}//~onCreate
	


	@Override
	public Object onRetainNonConfigurationInstance() {
		if (mAccessory != null) {
			return mAccessory;
		} else {
			return super.onRetainNonConfigurationInstance();
		}
	}

	@Override
	public void onResume() {
		super.onResume();

		if (mInputStream != null && mOutputStream != null) {
			return;
		}

		UsbAccessory[] accessories = mUsbManager.getAccessoryList();
		UsbAccessory accessory = (accessories == null ? null : accessories[0]);
		if (accessory != null) {
			if (mUsbManager.hasPermission(accessory)) {
				openAccessory(accessory);
			} else {
				synchronized (mUsbReceiver) {
					if (!mPermissionRequestPending) {
						mUsbManager.requestPermission(accessory,
								mPermissionIntent);
						mPermissionRequestPending = true;
					}
				}
			}
		} else {
			Log.d(TAG, "mAccessory is null");
		}
	}

	@Override
	public void onPause() {
		super.onPause();
		closeAccessory();
	}

	@Override
	public void onDestroy() {
		unregisterReceiver(mUsbReceiver);
		super.onDestroy();
	}

	private void openAccessory(UsbAccessory accessory) {
		mFileDescriptor = mUsbManager.openAccessory(accessory);
		if (mFileDescriptor != null) {
			mAccessory = accessory;
			FileDescriptor fd = mFileDescriptor.getFileDescriptor();
			mInputStream = new FileInputStream(fd);
			mOutputStream = new FileOutputStream(fd);
			Thread thread = new Thread(null, this, "DemoKit");
			thread.start();
			Log.d(TAG, "accessory opened");
			enableControls(true);
		} else {
			Log.d(TAG, "accessory open fail");
		}
	}

	private void closeAccessory() {
		enableControls(false);

		try {
			if (mFileDescriptor != null) {
				mFileDescriptor.close();
			}
		} catch (IOException e) {
		} finally {
			mFileDescriptor = null;
			mAccessory = null;
		}
	}

	protected void enableControls(boolean enable) {
	}
	
	private int composeInt(byte hi, byte lo) {
		int val = (int) hi & 0xff;
		val *= 256;
		val += (int) lo & 0xff;
		return val;
	}

	public void run() {
		int ret = 0;
		byte[] buffer = new byte[16384];
		int i;

		while (ret >= 0) {
			try {
				ret = mInputStream.read(buffer);
			} catch (IOException e) {
				break;
			}

			i = 0;
			while (i < ret) {
				int len = ret - i;

				switch (buffer[i]) {
				case 0x4:
					if (len >= 3) {
						Message m = Message.obtain(mHandler, MESSAGE_TEMPERATURE);
						char flag = (char)buffer[i + 1];
						int cps = composeInt(buffer[i + 2], buffer[i + 3]);
						m.obj = new GeigerMsg(flag, cps);
						mHandler.sendMessage(m);
					}
					i += 4;
					break;

				default:
					Log.d(TAG, "unknown msg: " + buffer[i]);
					i = len;
					break;
				}
			}

		}
	}

	Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {

			case MESSAGE_TEMPERATURE:
				GeigerMsg t = (GeigerMsg) msg.obj;
				handleGeigerMessage(t);
				break;

			}
		}
	};

	protected void handleGeigerMessage(GeigerMsg t) {
	}

	
	// click the mTouch button if the touch sensor has gone high	
	public void activateButton(final int data) {
		runOnUiThread(new Runnable() {
			@Override
			public void run() {
				String buttonID = "mButton" + data; // ID of button which is to be clicked e.g. mButton2
				int resID = getResources().getIdentifier(buttonID, "id", getPackageName());// find the identifier for the Button
				Button buttonToPlay = ((Button) findViewById(resID));
		ArduinoTouch.clickButton(buttonToPlay);
		ArduinoTouch.playAudio("channel_"+data);
/*				if (data == 0x00) {
					Button button0 = (Button)findViewById(R.id.mButton0);
//					button0.performClick();
					ArduinoTouch.clickButton(button0);
					ArduinoTouch.playAudio("channel_"+data); // play the audio tag	
				} // end if
				if (data == 0x01) {
					Button button1 = (Button)findViewById(R.id.mButton1);
					button1.performClick();
					ArduinoTouch.clickButton(activeButton);
				} // end if
				if (data == 0x02) {
					Button button2 = (Button)findViewById(R.id.mButton2);
					button2.performClick();
				} // end if
				if (data == 0x03) {
					Button button3 = (Button)findViewById(R.id.mButton3);
					button3.performClick();
				} // end if
				if (data == 0x04) {
					Button button4 = (Button)findViewById(R.id.mButton4);
					button4.performClick();
				} // end if
				if (data == 0x05) {
					Button button5 = (Button)findViewById(R.id.mButton5);
					button5.performClick();
				} // end if
				if (data == 0x06) {
					Button button6 = (Button)findViewById(R.id.mButton6);
					button6.performClick();
				} // end if
				if (data == 0x07) {
					Button button7 = (Button)findViewById(R.id.mButton7);
					button7.performClick();
				} // end if
				if (data == 0x08) {
					Button button8 = (Button)findViewById(R.id.mButton8);
					button8.performClick();
				} // end if
				if (data == 0x09) {
					Button button9 = (Button)findViewById(R.id.mButton9);
					button9.performClick();
				} // end if
				if (data == 0x0A) {
					Button button10 = (Button)findViewById(R.id.mButton10);
					button10.performClick();
				} // end if
				if (data == 0x0B) {
					Button button11 = (Button)findViewById(R.id.mButton11);
					button11.performClick();
				} // end if
				if (data == 0x0C) {
					Button button12 = (Button)findViewById(R.id.mButton12);
					button12.performClick();
				} // end if
				if (data == 0x0D) {
					Button button13 = (Button)findViewById(R.id.mButton13);
					button13.performClick();
				} // end if
				if (data == 0x0E) {
					Button button14 = (Button)findViewById(R.id.mButton14);
					button14.performClick();
				} // end if
				if (data == 0x0F) {
					Button button15 = (Button)findViewById(R.id.mButton15);
					button15.performClick();
				} // end if
*/
			} // end run
		}); // end thread
	} // end activate Button	


} // ~ArduinoTouchActivity

